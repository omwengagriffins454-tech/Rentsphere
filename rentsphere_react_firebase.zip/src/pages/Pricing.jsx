import React from 'react'
export default function Pricing(){ return (<div><h2>Pricing</h2><p>Free / Premium / Business — contact us for custom plans.</p></div>) }