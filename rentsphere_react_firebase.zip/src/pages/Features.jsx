import React from 'react'
export default function Features(){ return (<div><h2>Features</h2><ul><li>Verified Listings</li><li>Direct Connections</li><li>Smart Search</li></ul></div>) }