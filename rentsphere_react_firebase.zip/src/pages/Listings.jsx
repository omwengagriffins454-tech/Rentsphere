import React, {useEffect, useState} from 'react'
import { collection, getDocs, query, orderBy } from 'firebase/firestore'
import { db } from '../firebase'
import ListingCard from '../components/ListingCard'

export default function Listings(){
  const [items, setItems] = useState([])
  useEffect(()=>{
    const q = query(collection(db,'listings'), orderBy('createdAt','desc'))
    getDocs(q).then(snap=>{
      const arr = snap.docs.map(d=>({id:d.id,...d.data()}))
      setItems(arr)
    })
  },[])
  return (
    <div>
      <h2>Listings</h2>
      <div className="grid" style={{gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))'}}>
        {items.map(it=> <ListingCard key={it.id} item={it} />)}
      </div>
    </div>
  )
}