import React from 'react'
export default function ListingCard({item}){
  return (
    <div className="listing-card">
      <h3>{item.title}</h3>
      <p style={{color:'var(--muted)'}}>{item.location} · KES {item.price}</p>
      {item.imageUrl && <img src={item.imageUrl} alt='' style={{width:'100%',borderRadius:8,marginTop:8}} />}
      <p style={{marginTop:8}}>{item.description}</p>
    </div>
  )
}